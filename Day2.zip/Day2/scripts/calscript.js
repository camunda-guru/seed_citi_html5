/**
 * Created by BALASUBRAMANIAM on 14-01-2015.
 */
$(document).ready(function()
{
    $.datepicker.setDefaults(
    {
        dateFormat:'dd-mm-yy',
        minDate:'22-09-2015',
        maxDate:'22-12-2015'

    });

        //$( "#datepicker" ).datepicker( );




    $("#monthlycal").datepicker(
        {
            showOn:"button",
            buttonImage: "images/calendaricon.jpg",
            buttonText: "Select Travel Date",
            numberOfMonths:3,
            showAnim:"slide"


        }

    );

});