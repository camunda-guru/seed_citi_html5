/**
 * Created by BALASUBRAMANIAM on 02-08-2017.
 */
flxApp.controller('lineChartController',['$scope','quandlFinService',
    function($scope,quandlFinService)
{

    quandlFinService.quandlClosure().then(function(res)
    {
        console.log(res);
        i=0;
        $scope.labels = [];//x axis

        $scope.series = ['Series A'];
        $scope.data = [[]]; //y axis
        angular.forEach(res.data.dataset_data.data,function(key,value)
        {
          console.log(key[0]);
            $scope.labels.push(key[0]);
            for (i in key) {
                if((i==1)) {
                    console.log(key[i]);
                    $scope.data[0].push(key[i]);
                }
            }

        })



        $scope.options = {
            scales: {
                yAxes: [
                    {
                        id: 'y-axis-1',
                        type: 'linear',
                        display: true,
                        position: 'left'
                    }
                ]
            }
        };


    })

}])