/**
 * Created by BALASUBRAMANIAM on 02-08-2017.
 */
flxServiceModule=angular.module('FLXServiceModule',[]);

flxServiceModule.service('quandlFinService',['$http',function($http)
{

    var liborData=function()
    {
        return $http(
            {
                method: 'get',
                datatype: 'jsonp',
                headers: {
                    'Content-Type': 'application/json'

                },
                url: 'https://www.quandl.com/api/v3/datasets/WIKI/FB/data.json'
            }
        ).then(function(response)
            {
                return response;
            })
    }


    return{
        quandlClosure:liborData
    }

}])


flxServiceModule.service('quandlFinServicejson',['$http',function($http)
{

    var liborData=function()
    {
        return $http(
            {
                method: 'get',
                datatype: 'jsonp',
                headers: {
                    'Content-Type': 'application/json'

                },
                url: 'scripts/financialdata.json'
            }
        ).then(function(response)
            {
                return response;
            })
    }


    return{
        quandlClosureJson:liborData
    }

}])