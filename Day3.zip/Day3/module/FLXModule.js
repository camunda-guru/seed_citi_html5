/**
 * Created by BALASUBRAMANIAM on 02-08-2017.
 */
flxApp=angular.module('FlxApp',['chart.js','FLXServiceModule']);