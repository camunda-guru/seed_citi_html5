/**
 * Created by BALASUBRAMANIAM on 08-12-2015.
 */
$(function () {


    $.ajax(
        {

            url:"https://www.quandl.com/api/v3/datasets/BOF/QS_M_IEUTIO9M.json?auth_token=nHYufVSHw4383Wy4_Ekg",
            type:'Get',
            contentType: 'application/json',

            dataType:'json',
            success:function(jsondata)
            {
                console.log(jsondata);
                thead = $('<thead></thead>').appendTo("#my-table");
                row = $('<tr></tr>').appendTo(thead);
                th = $('<th></th>').text("Date").appendTo(row);
                th = $('<th></th>').text("Interest Rate").appendTo(row);
                tbody = $('<tbody></tbody>').appendTo("#my-table");
                $.each(jsondata.dataset.data,function(item,value)
                {


                    row = $('<tr></tr>').appendTo(tbody);
                    $('<td></td>').text(value[0]).appendTo(row);
                    $('<td></td>').text(value[1]).appendTo(row);






                }) ;

                $('#my-table')
                    .tablesorter({
                        theme: 'blue',
                        widget: ['zebra']
                    });

                $('#my-table').bdt();



            },
            failure:function(x)
            {
                console.log(x.error());
            }



        });



});