/**
 * Created by BALASUBRAMANIAM on 31-07-2017.
 */
$(function () {
    $("#city").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: "http://gd.geobytes.com/AutoCompleteCity?callback=?&q="+request.term,
                type: "GET",
                contentType: 'application/json; charset=utf-8',
                dataType: "jsonp",
                success: function (data) {
                    response(data);
                    $.each(data, function (item, value) {
                        console.log(value);
                    });
                },
                error:function(msg)
                {
                    console.log(msg);
                }
            });
        }
    });
});

function save()
{
   var fileRef= document.getElementById("photo");
    console.log(fileRef.files.length);
    var filePattern=/image.*/;
    for(i=0;i<fileRef.files.length;i++)
    {
        if(fileRef.files[i].type.match(filePattern))
            storeImage(i,fileRef.files[i]);
    }


}

function storeImage(position, file)
{
    var fileReader =new FileReader();
    fileReader.readAsDataURL(file);
    fileReader.onload=function()
    {
        window.localStorage.setItem("Image"+position,fileReader.result);
    }
}