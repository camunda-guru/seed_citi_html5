/**
 * Created by BALASUBRAMANIAM on 31-07-2017.
 */
for(i=0;i<window.localStorage.length;i++)
{
    if(window.localStorage.getItem("Image"+i)!=undefined)
    {
        displayPhoto(window.localStorage.getItem("Image"+i));
    }
}

function displayPhoto(file)
{
    var img = new Image();
    img.width=100;
    img.height=100;
    img.onload = function (evt) {
        var photoref = document.getElementById("docs");
        photoref.appendChild(img);
        node = document.createElement("hr");
        photoref.appendChild(node);
    }

    img.src = file;
}