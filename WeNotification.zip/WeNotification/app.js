/**
 * Created by BALASUBRAMANIAM on 01-12-2015.
 */
    // request permission on page load


function notifyMe() {
    if (!Notification) {
        alert('Desktop notifications not available in your browser. Try Chromium.');
        return;
    }

    if (Notification.permission !== "granted")
        Notification.requestPermission();
    else {
        var notification = new Notification('Notification title', {
            icon: 'images/tweet.jpg',
            body: "Hey there! You've been notified!"
        });

        notification.onclick = function () {
            notification.close();
            window.open("https://mail.google.com/mail");
        };

    }

}
window.onload=notifyMe;